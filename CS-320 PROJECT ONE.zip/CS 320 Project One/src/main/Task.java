package main;

import java.util.UUID;

public class Task {
	private final String taskId;
	private String name;
	private String description;

	public Task(String name, String description) {
		
		this.taskId = UUID.randomUUID().toString().substring(0, 10);
		setName(name);
		setDescription(description);
	}
	
	public String getTaskId() {
		return taskId;
	}
	
	public void setName(String name) {
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.name = name;
	}
	
	public void setDescription(String description) {
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}

}
