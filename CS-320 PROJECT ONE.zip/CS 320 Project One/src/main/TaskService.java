package main;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
	
	private Map<String, Task> tasks;
	
	public TaskService() {
		this.tasks = new HashMap<>();
	}
	
	public void addTask(Task task) {
		tasks.put(task.getTaskId(), task);
	}
	
	public Task updateTask(String taskId, String name, String description) {
		Task task = tasks.get(taskId);
		if(task != null) {
			task.setName(name);
			task.setDescription(description);
		}
		return task;
	}
	
	public void deleteTask(String taskId) {
		tasks.remove(taskId);
	}
	
	public Task getTask(String taskId) {
		return tasks.get(taskId);
	}

}
