package main;
import java.util.HashMap;
import java.util.Map;
public class AppointmentService {
	private Map<String, Appointment> appointments = new HashMap<>();
	
	public boolean addAppointment(Appointment appointment) {
		if(appointment != null && !appointments.containsKey(appointment.getAppointmentID())) {
			appointments.put(appointment.getAppointmentID(), appointment);
			return true;
		}
		
		return false;
	}
	
	public boolean deleteAppointment(String appointmentID) {
		return appointments.remove(appointmentID) != null;
	}
	public Appointment getAppointment(String appointmentID) {
		return appointments.get(appointmentID);
	}
}
