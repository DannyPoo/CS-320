package main;

import java.util.Date;

public class Appointment {
	private final String appointmentID;
	private Date appointmentDate;
	private String description;
	
	public Appointment(String appointmentID, Date appointmentDate, String description) {
		if(appointmentID == null || appointmentID.length() > 10 || appointmentDate == null || appointmentDate.before(new Date()) || description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid appointment paramters");
		}
		this.appointmentID = appointmentID;
		this.setAppointmentDate(appointmentDate);
		this.setDescription(description);
	}
	
	public String getAppointmentID() {
		return appointmentID;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		if(!appointmentDate.before(new Date()))
			this.appointmentDate = appointmentDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if(description != null && description.length() <= 50)
			this.description = description;
	}
}
