package test;

public class ContactTest {

}
