package test;

import main.Appointment;
import main.AppointmentService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

	
	@Test
	public void testAppointmentCreation() {
		Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 10000), "Testing");
		assertNotNull(appointment);
	}
	
	@Test
	public void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 10000), "Testing");
		assertTrue(service.addAppointment(appointment));
		assertNotNull(service.getAppointment("1234567890"));
	}
	
	@Test
	public void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 10000), "Testing");
		service.addAppointment(appointment);
		assertTrue(service.deleteAppointment("1234567890"));
		assertNull(service.getAppointment("1234567890"));
	}
	
	@Test
	public void testInvalidAppointmentCreation() {
		assertThrows(IllegalArgumentException.class, () -> { new Appointment(null, new Date(System.currentTimeMillis() + 10000), "Testing"); });
		assertThrows(IllegalArgumentException.class, () -> { new Appointment("1234567890", null, "Testing"); });
		assertThrows(IllegalArgumentException.class, () -> { new Appointment("1234567890" , new Date(System.currentTimeMillis() + 10000), null); });
		assertThrows(IllegalArgumentException.class, () -> { new Appointment("12345678901", new Date(System.currentTimeMillis() + 10000), "Testing"); });
		assertThrows(IllegalArgumentException.class, () -> { new Appointment("12345678901", new Date(System.currentTimeMillis() - 10000), "Testing"); });
		assertThrows(IllegalArgumentException.class, () -> { new Appointment("1234567890" , new Date(System.currentTimeMillis() + 10000), "ThisIsWayTooLongDescriptionToBeValidAgainstTheCharacterLimits"); });
	}
}
