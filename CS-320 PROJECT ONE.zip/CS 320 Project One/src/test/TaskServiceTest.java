package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import main.Task;
import main.TaskService;

public class TaskServiceTest {
	
	private TaskService taskService;
	
	@BeforeEach
	public void setUp() {
		taskService = new TaskService();
	}
	
	@Test
	public void testAddTask() {
		Task task = new Task("TestTask", "TestTaskDescription");
		taskService.addTask(task);
		Task retrievedTask = taskService.getTask(task.getTaskId());
		assertEquals(task, retrievedTask);
	}
	
	@Test
	public void testUpdateTask() {
		Task task = new Task("TestTask", "TestTaskDescription");
		taskService.addTask(task);
		
		taskService.updateTask(task.getTaskId(), "NewName", "NewDescription");
		
		Task updatedTask = taskService.getTask(task.getTaskId());
		assertEquals("NewName", updatedTask.getName());
		assertEquals("NewDescription", updatedTask.getDescription());
	}
	
	@Test
	public void taskDeleteTask() {
		Task task = new Task("TestTask", "TestTaskDescription");
		taskService.addTask(task);
		taskService.deleteTask(task.getTaskId());
		assertNull(taskService.getTask(task.getTaskId()));
	}
	
	@Test
	public void testTaskProperties() {
		Task task = new Task("TestTask", "TestTaskDescription");
		assertEquals("TestTask", task.getName());
		assertEquals("TestTaskDescription", task.getDescription());
	}
	
	@Test
	public void testInvalidTaskCreation() {
		assertThrows(IllegalArgumentException.class, () -> { new Task(null, "desccription"); });
		assertThrows(IllegalArgumentException.class, () -> { new Task("name", null); });
		assertThrows(IllegalArgumentException.class, () -> { new Task("ThisIsAVeryLongNameTestingTheCharacterLimit", "desccription"); });
		assertThrows(IllegalArgumentException.class, () -> { new Task("name", "ThisIsAVeryLongDescriptionTestingTheAllowedCharacterLimit"); });
	}
	
	@Test
	public void testInvalidTaskUpdate() {
		Task task = new Task("TestTask", "TestTaskDescription");
		taskService.addTask(task);
		
		assertThrows(IllegalArgumentException.class, () -> { taskService.updateTask(task.getTaskId(), null, "desccription"); });
		assertThrows(IllegalArgumentException.class, () -> { taskService.updateTask(task.getTaskId(), "name", null); });
		assertThrows(IllegalArgumentException.class, () -> { taskService.updateTask(task.getTaskId(), "ThisIsAVeryLongNameTestingTheCharacterLimit", "desccription"); });
		assertThrows(IllegalArgumentException.class, () -> { taskService.updateTask(task.getTaskId(), "name", "ThisIsAVeryLongDescriptionTestingTheAllowedCharacterLimit"); });
	}
	
}
