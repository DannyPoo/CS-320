package test;

public class AppointmentTest {

}
